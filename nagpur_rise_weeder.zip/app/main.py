"""
WEB DASHBOARD / UI - Jury Demo
Streamlit based modern agricultural dashboard
Run: streamlit run app/main.py

Features:
- Sidebar: video source, thresholds, corridor width, language toggle (EN/MR/HI)
- Live video with overlay
- Metric cards + rolling actuation console
"""
import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '.'))

import cv2
import time
import streamlit as st
import numpy as np
from detector import CottonWeedDetector, IntraRowEngine
from actuator import ActuationController
from pathlib import Path

# --- Language Pack for Vidarbha Alignment ---
LANG = {
    'en': {
        'title': '🌱 AI-Powered Precision Intra-Row Weeder - Cotton',
        'subtitle': 'Nagpur RISE Hackathon | Vidarbha Agri Innovation Cohort',
        'sidebar': 'Controls',
        'video_src': 'Video Source',
        'conf': 'Confidence Threshold',
        'corridor': 'Intra-Row Corridor Width (%)',
        'trigger': 'Trigger Line Position (%)',
        'lang': 'Language',
        'weeds': 'Weeds Detected',
        'intrarow': 'Intra-Row Weeds',
        'pulses': 'Pulses Fired',
        'saved': 'Herbicide Saved',
        'latency': 'Model Latency',
        'fps': 'FPS',
        'console': 'Live Actuation Console (ESP32 Solenoid Log)',
        'upload': 'Upload field video (mp4) or use webcam',
        'no_model': 'No custom model found - using MOCK detector for demo',
        'model_loaded': 'Custom YOLO Model Loaded',
        'start': '▶️ Start Perception Loop',
        'stop': '⏹ Stop',
        'roboflow_tip': 'Tip: Plug Roboflow model as best.pt in models/ folder'
    },
    'mr': {
        'title': '🌱 एआय-शक्तीवर आधारित आंतर-ओळ तणनाशक - कापूस',
        'subtitle': 'नागपूर RISE हॅकाथॉन | विदर्भ कृषी नवोपक्रम',
        'sidebar': 'नियंत्रणे',
        'video_src': 'व्हिडिओ स्रोत',
        'conf': 'आत्मविश्वास थ्रेशोल्ड',
        'corridor': 'आंतर-ओळ रुंदी (%)',
        'trigger': 'ट्रिगर रेषा स्थान (%)',
        'lang': 'भाषा',
        'weeds': 'तण आढळले',
        'intrarow': 'आंतर-ओळ तण',
        'pulses': 'फवारणी सक्रिय',
        'saved': 'औषध बचत',
        'latency': 'मॉडेल विलंब',
        'fps': 'FPS',
        'console': 'लाइव्ह ॲक्च्युएशन कन्सोल',
        'upload': 'शेताचा व्हिडिओ अपलोड करा',
        'no_model': 'सानुकूल मॉडेल नाही - डेमो साठी मॉक वापरत आहे',
        'model_loaded': 'सानुकूल YOLO मॉडेल लोड केले',
        'start': '▶️ सुरू करा',
        'stop': '⏹ थांबा',
        'roboflow_tip': 'टीप: Roboflow मॉडेल best.pt म्हणून models/ मध्ये ठेवा'
    },
    'hi': {
        'title': '🌱 एआई-संचालित सटीक अंतर-पंक्ति वीडर - कपास',
        'subtitle': 'नागपुर RISE हैकाथॉन | विदर्भ कृषि नवाचार',
        'sidebar': 'नियंत्रण',
        'video_src': 'वीडियो स्रोत',
        'conf': 'विश्वास सीमा',
        'corridor': 'अंतर-पंक्ति चौड़ाई (%)',
        'trigger': 'ट्रिगर लाइन स्थिति (%)',
        'lang': 'भाषा',
        'weeds': 'खरपतवार मिले',
        'intrarow': 'अंतर-पंक्ति खरपतवार',
        'pulses': 'स्प्रे सक्रिय',
        'saved': 'दवा बचत',
        'latency': 'मॉडल विलंबता',
        'fps': 'FPS',
        'console': 'लाइव एक्चुएशन कंसोल',
        'upload': 'खेत वीडियो अपलोड करें',
        'no_model': 'कस्टम मॉडल नहीं - डेमो के लिए मॉक',
        'model_loaded': 'कस्टम YOLO मॉडल लोडेड',
        'start': '▶️ शुरू करें',
        'stop': '⏹ रोकें',
        'roboflow_tip': 'टिप: Roboflow मॉडल को models/best.pt में रखें'
    }
}

st.set_page_config(page_title="Intra-Row Weeder | RISE", layout="wide", page_icon="🌱")

def get_text(key):
    lang_code = st.session_state.get('lang_code', 'en')
    return LANG[lang_code][key]

# Sidebar
with st.sidebar:
    st.title("🌾 RISE CotWeed")
    lang_code = st.selectbox("🌐 Language / भाषा", ["en", "mr", "hi"], index=0, format_func=lambda x: {"en":"English","mr":"मराठी","hi":"हिन्दी"}[x], key="lang_code")
    T = LANG[lang_code]
    
    st.header(T['sidebar'])
    video_mode = st.radio(T['video_src'], ["Sample Field Video", "Upload MP4", "Webcam (0)"], index=0)
    conf_thresh = st.slider(T['conf'], 0.1, 0.9, 0.45, 0.05)
    corridor_pct = st.slider(T['corridor'], 10, 60, 30, 5)
    trigger_pct = st.slider(T['trigger'], 50, 90, 75, 5)
    num_nozzles = st.slider("Nozzle Array (valves)", 2, 8, 4, 1)
    use_mock = st.checkbox("Force MOCK Detector (no weights needed)", value=False)
    st.info(T['roboflow_tip'])

    model_path = None
    # Check for models/best.pt
    possible = [Path("models/best.pt"), Path("app/../models/best.pt"), Path("models/cotton_weed.pt")]
    for p in possible:
        if p.exists():
            model_path = str(p)
            break
    if model_path and not use_mock:
        st.success(f"{T['model_loaded']}: {model_path}")
    else:
        st.warning(T['no_model'])

# Main
st.title(T['title'])
st.caption(T['subtitle'])
st.markdown("---")

col1, col2 = st.columns([2.2, 1])

# State
if 'running' not in st.session_state:
    st.session_state.running = False

# File handling
video_file = None
if video_mode == "Upload MP4":
    uploaded = st.sidebar.file_uploader(T['upload'], type=["mp4","avi","mov","mkv"])
    if uploaded:
        temp_path = f"/tmp/{uploaded.name}"
        with open(temp_path, "wb") as f:
            f.write(uploaded.read())
        video_file = temp_path
elif video_mode == "Sample Field Video":
    # Expect sample in data/sample.mp4 else use demo loop
    for cand in ["data/sample.mp4", "sample.mp4", "field.mp4"]:
        if Path(cand).exists():
            video_file = cand
            break

# Controls
c_start, c_stop, c_reset = st.columns(3)
with c_start:
    if st.button(T['start']):
        st.session_state.running = True
with c_stop:
    if st.button(T['stop']):
        st.session_state.running = False
with c_reset:
    if st.button("🔄 Reset Telemetry"):
        st.session_state.pop('controller', None)

# Placeholders
with col1:
    video_placeholder = st.empty()
with col2:
    metric_placeholder = st.empty()
    console_placeholder = st.empty()

# Core Loop
if st.session_state.running:
    # Init engines
    detector = CottonWeedDetector(model_path=model_path if not use_mock else None, conf_thresh=conf_thresh, use_mock=use_mock or (model_path is None))
    intra_engine = IntraRowEngine(num_nozzles=num_nozzles, corridor_ratio=corridor_pct/100.0, trigger_ratio=trigger_pct/100.0)
    if 'controller' not in st.session_state:
        st.session_state.controller = ActuationController(num_nozzles=num_nozzles)
    controller: ActuationController = st.session_state.controller

    # Open video source
    if video_mode == "Webcam (0)":
        cap = cv2.VideoCapture(0)
    else:
        if video_file:
            cap = cv2.VideoCapture(video_file)
        else:
            # Synthetic field canvas for demo when no video
            cap = None

    frame_idx = 0
    fps_t0 = time.time()
    
    while st.session_state.running:
        if cap is not None:
            ret, frame = cap.read()
            if not ret:
                # loop video
                if video_file:
                    cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
                    continue
                else:
                    break
        else:
            # Generate synthetic cotton field background
            frame = np.zeros((720, 1280, 3), dtype=np.uint8)
            frame[:] = (45, 120, 35)  # soil green-brown
            # draw soil texture lines
            for i in range(0, 1280, 40):
                cv2.line(frame, (i,0), (i,720), (35,100,25), 1)

        # Inference
        detections, latency_ms = detector.detect(frame)
        roi = intra_engine.get_roi(frame.shape[1], frame.shape[0])

        triggered = []
        weed_count = 0
        intra_count = 0
        for det in detections:
            if det.cls == 'weed':
                weed_count += 1
                if intra_engine.is_intrarow(det, roi):
                    intra_count += 1
                if intra_engine.check_trigger(det, roi):
                    ev = intra_engine.calculate_actuation(det, roi)
                    payload = controller.emit(ev)
                    triggered.append(ev)

        controller.update_detection_stats(weed_count, intra_count)
        # FPS calc
        frame_idx += 1
        if frame_idx % 10 == 0:
            fps = 10 / (time.time() - fps_t0 + 1e-6)
            fps_t0 = time.time()
            controller.update_perf(fps, latency_ms)
        else:
            controller.update_perf(0, latency_ms)

        # Visualization
        vis = intra_engine.draw_overlay(frame, detections, roi, triggered)
        # Convert BGR->RGB for Streamlit
        vis_rgb = cv2.cvtColor(vis, cv2.COLOR_BGR2RGB)

        # Metrics
        metrics = controller.get_metrics()

        with col1:
            video_placeholder.image(vis_rgb, channels="RGB", use_container_width=True)

        with col2:
            m1, m2 = st.columns(2)
            m1.metric(T['weeds'], metrics['weeds_detected'], f"+{weed_count}")
            m2.metric(T['intrarow'], metrics['intrarow_weeds'])
            m3, m4 = st.columns(2)
            m3.metric(T['pulses'], metrics['pulses_fired'])
            m4.metric(T['saved'], f"{metrics['herbicide_saved_pct']}%")
            m5, m6 = st.columns(2)
            m5.metric(T['latency'], f"{metrics['avg_latency_ms']} ms")
            m6.metric(T['fps'], f"{metrics['avg_fps']}")

            # Console
            logs = list(controller.event_log)[:15]
            log_text = ""
            for l in logs:
                icon = "🔴" if l['is_intrarow'] else "🟠"
                log_text += f"{icon} [{l['timestamp'].split('T')[1][:8]}] N{l['nozzle_id']} {l['pulse_ms']}ms area:{l['weed_area_px']} conf:{l['confidence']} -> {l['cmd']}\n"
            console_placeholder.code(log_text or "Waiting for weeds...", language="json")

        time.sleep(0.03)  # ~30 FPS cap
        # Streamlit rerun guard - we use loop but allow stop button via session state check
        # In production, replace with st.experimental_rerun pattern or async

    if cap is not None:
        cap.release()
else:
    st.info("Press Start to begin perception loop. Upload a cotton field video traversing crop rows (down-facing camera) for best demo.")
    st.image("https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=1200", caption="Down-facing camera simulation - cotton rows")

# Footer
st.markdown("---")
st.markdown("**Architecture**: `YOLOv8n/v11` → `IntraRowEngine` (ROI + Trigger) → `ActuationController` (JSON/MQTT) → `ESP32 Solenoid Array` | **Chemical Saving Target**: 80% vs broadcast | Built for Vidarbha cotton belt.")
