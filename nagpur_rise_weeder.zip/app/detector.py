"""
CORE VISION & INTRA-ROW TRACKING ENGINE
Nagpur RISE Hackathon - Cotton Value Chain
AI-Powered Precision Intra-Row Weeder

Handles:
- Video/webcam ingestion
- YOLO detection (cotton vs weed) with mock fallback
- Dynamic Intra-Row Corridor + Actuation Trigger Logic
- Nozzle mapping & pulse calculation
"""
import cv2
import time
import numpy as np
from dataclasses import dataclass
from typing import List, Tuple, Optional, Dict
import random

@dataclass
class Detection:
    cls: str  # 'cotton' or 'weed'
    conf: float
    bbox: Tuple[int, int, int, int]  # x1, y1, x2, y2
    center: Tuple[int, int]
    area: int

@dataclass
class ActuationEvent:
    nozzle_id: int
    x_offset: int
    pulse_ms: int
    weed_area_px: int
    confidence: float
    is_intrarow: bool
    timestamp: float

class CottonWeedDetector:
    def __init__(self, model_path: Optional[str] = None, conf_thresh: float = 0.45, use_mock: bool = False):
        """
        model_path: path to YOLOv8/YOLOv11 custom weight (e.g. best.pt from Roboflow)
        If not provided or load fails, switches to mock detector for demo without weights.
        """
        self.conf_thresh = conf_thresh
        self.model = None
        self.use_mock = use_mock
        self.class_names = {0: 'cotton', 1: 'weed'}
        
        if not use_mock:
            try:
                from ultralytics import YOLO
                if model_path:
                    self.model = YOLO(model_path)
                    print(f"[DETECTOR] Loaded custom model: {model_path}")
                else:
                    # Use nano as base - will still detect plants if COCO-pretrained, but we remap
                    # For hackathon demo, we try yolov8n.pt which is auto-downloaded
                    self.model = YOLO('yolov8n.pt')
                    print("[DETECTOR] Loaded YOLOv8n (base). Using fallback class mapping.")
                # Override class names if custom model has correct names
                if hasattr(self.model, 'names'):
                    # Check if names contain cotton/weed
                    names = self.model.names
                    if any('cotton' in str(v).lower() or 'weed' in str(v).lower() for v in names.values()):
                        self.class_names = names
            except Exception as e:
                print(f"[DETECTOR] YOLO load failed ({e}), switching to MOCK detector for demo.")
                self.use_mock = True
        else:
            print("[DETECTOR] Running in MOCK mode - synthetic detections for demo.")

    def _mock_detections(self, frame: np.ndarray) -> List[Detection]:
        """Generates plausible mock cotton/weed detections for video demo without model weights."""
        h, w = frame.shape[:2]
        detections = []
        # Simulate cotton line down center
        center_x = w // 2
        # Mock cotton plants (regular spacing)
        for y in range(50, h, 180):
            jitter_x = random.randint(-40, 40)
            x1 = center_x + jitter_x - 35
            y1 = y - 30
            x2 = center_x + jitter_x + 35
            y2 = y + 60
            detections.append(Detection(
                cls='cotton', conf=random.uniform(0.75, 0.96),
                bbox=(x1,y1,x2,y2), center=(center_x+jitter_x, y+15),
                area=(x2-x1)*(y2-y1)
            ))
        # Mock weeds - some intra-row (challenging) and some inter-row
        num_weeds = random.randint(0, 4)
        for _ in range(num_weeds):
            wx = random.randint(20, w-20)
            wy = random.randint(100, h-50)
            size = random.randint(15, 45)
            detections.append(Detection(
                cls='weed', conf=random.uniform(0.55, 0.92),
                bbox=(wx-size, wy-size, wx+size, wy+size),
                center=(wx, wy), area=size*size*4
            ))
        return [d for d in detections if d.conf >= self.conf_thresh]

    def detect(self, frame: np.ndarray) -> Tuple[List[Detection], float]:
        """Returns detections + inference latency ms"""
        t0 = time.time()
        if self.use_mock or self.model is None:
            dets = self._mock_detections(frame)
            latency = (time.time() - t0) * 1000
            return dets, latency

        # Real YOLO inference
        results = self.model.predict(frame, conf=self.conf_thresh, verbose=False)
        detections = []
        for r in results:
            for box in r.boxes:
                cls_id = int(box.cls[0])
                conf = float(box.conf[0])
                x1, y1, x2, y2 = map(int, box.xyxy[0])
                # Map COCO classes to our 2 classes if using base model
                label = self.class_names.get(cls_id, 'weed')
                # If base COCO model, treat potted plant / etc as weed for demo mapping
                if label not in ['cotton', 'weed']:
                    # Heuristic: if using COCO yolov8n, map 'potted plant' -> cotton/weed randomly for demo
                    # In production you will use custom Roboflow weight with proper names
                    label = 'weed' if random.random() > 0.3 else 'cotton'
                cx = (x1+x2)//2
                cy = (y1+y2)//2
                area = (x2-x1)*(y2-y1)
                detections.append(Detection(label, conf, (x1,y1,x2,y2), (cx,cy), area))
        latency = (time.time() - t0) * 1000
        return detections, latency

class IntraRowEngine:
    """
    Manages:
    - Intra-Row Corridor (center strip)
    - Actuation Trigger Line
    - Nozzle mapping
    """
    def __init__(self, num_nozzles: int = 4, corridor_ratio: float = 0.30, trigger_ratio: float = 0.75):
        self.num_nozzles = num_nozzles
        self.corridor_ratio = corridor_ratio # width of intra-row strip relative to frame width
        self.trigger_ratio = trigger_ratio # Y position (0-1) where actuation triggers
        self.last_triggered = {}  # weed center hash -> timestamp to avoid double firing

    def get_roi(self, frame_w: int, frame_h: int) -> Dict:
        corridor_w = int(frame_w * self.corridor_ratio)
        center = frame_w // 2
        corridor_x1 = center - corridor_w//2
        corridor_x2 = center + corridor_w//2
        trigger_y = int(frame_h * self.trigger_ratio)
        return {
            'corridor': (corridor_x1, 0, corridor_x2, frame_h),
            'corridor_x1': corridor_x1,
            'corridor_x2': corridor_x2,
            'trigger_y': trigger_y,
            'frame_w': frame_w,
            'frame_h': frame_h
        }

    def is_intrarow(self, det: Detection, roi: Dict) -> bool:
        cx, _ = det.center
        return roi['corridor_x1'] <= cx <= roi['corridor_x2']

    def check_trigger(self, det: Detection, roi: Dict, debounce_ms: int = 500) -> bool:
        """Check if weed bbox intersects trigger line"""
        if det.cls != 'weed':
            return False
        x1, y1, x2, y2 = det.bbox
        trigger_y = roi['trigger_y']
        # Trigger when weed crosses the line (bbox contains line or is below)
        if y1 <= trigger_y <= y2 or (abs((y1+y2)//2 - trigger_y) < 20):
            key = f"{det.center[0]//20}_{det.center[1]//20}"
            now = time.time()*1000
            if key in self.last_triggered and now - self.last_triggered[key] < debounce_ms:
                return False
            self.last_triggered[key] = now
            return True
        return False

    def calculate_actuation(self, det: Detection, roi: Dict) -> ActuationEvent:
        """Maps weed X position to nozzle index + pulse duration based on area"""
        frame_w = roi['frame_w']
        nozzle_width = frame_w / self.num_nozzles
        cx, _ = det.center
        
        nozzle_id = int(cx // nozzle_width) + 1  # 1-indexed for hardware
        nozzle_id = max(1, min(self.num_nozzles, nozzle_id))
        
        x_offset = int(cx - (frame_w // 2))  # offset from center for rover alignment
        
        # Pulse duration: 40ms base + area scaled, capped 40-180ms
        # Larger weed = longer spray
        area_norm = np.clip(det.area / 2500.0, 0.2, 3.0)
        pulse_ms = int(40 + area_norm * 35)
        pulse_ms = max(40, min(180, pulse_ms))

        return ActuationEvent(
            nozzle_id=nozzle_id,
            x_offset=x_offset,
            pulse_ms=pulse_ms,
            weed_area_px=det.area,
            confidence=det.conf,
            is_intrarow=self.is_intrarow(det, roi),
            timestamp=time.time()
        )

    def draw_overlay(self, frame: np.ndarray, detections: List[Detection], roi: Dict, triggered_events: List[ActuationEvent]) -> np.ndarray:
        """Draws corridor, trigger line, boxes - jury-ready visualization"""
        vis = frame.copy()
        h, w = frame.shape[:2]
        # 1. Intra-row corridor (semi-transparent)
        overlay = vis.copy()
        cv2.rectangle(overlay, (roi['corridor_x1'], 0), (roi['corridor_x2'], h), (0, 255, 255), -1)
        cv2.addWeighted(overlay, 0.12, vis, 0.88, 0, vis)
        # Corridor borders
        cv2.line(vis, (roi['corridor_x1'], 0), (roi['corridor_x1'], h), (0, 255, 255), 2)
        cv2.line(vis, (roi['corridor_x2'], 0), (roi['corridor_x2'], h), (0, 255, 255), 2)
        cv2.putText(vis, "INTRA-ROW CORRIDOR", (roi['corridor_x1']+5, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0,180,180), 2)

        # 2. Trigger line
        ty = roi['trigger_y']
        cv2.line(vis, (0, ty), (w, ty), (0, 0, 255), 3)
        cv2.putText(vis, "ACTUATION TRIGGER", (10, ty-10), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0,0,255), 2)

        # 3. Nozzle zones on top
        nozzle_width = w / self.num_nozzles
        for i in range(self.num_nozzles):
            x = int(i*nozzle_width)
            cv2.line(vis, (x, 0), (x, 60), (255,255,255), 1)
            cv2.putText(vis, f"N{i+1}", (x+10, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255,255,255), 1)

        # 4. Detections
        for det in detections:
            x1,y1,x2,y2 = det.bbox
            is_intra = self.is_intrarow(det, roi)
            if det.cls == 'cotton':
                color = (0, 200, 0)  # green
            else:
                color = (0, 0, 255) if is_intra else (255, 100, 0)  # red intra, orange inter
            cv2.rectangle(vis, (x1,y1), (x2,y2), color, 2)
            label = f"{det.cls} {det.conf:.2f} {'[INTRA]' if is_intra and det.cls=='weed' else ''}"
            cv2.putText(vis, label, (x1, y1-8), cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)

        # 5. Triggered pulse flash
        for ev in triggered_events:
            cx = w//2 + ev.x_offset
            cv2.circle(vis, (cx, ty), 18, (0,0,255), -1)
            cv2.putText(vis, f"FIRE N{ev.nozzle_id} {ev.pulse_ms}ms", (cx-50, ty-25), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0,0,255), 2)

        return vis
